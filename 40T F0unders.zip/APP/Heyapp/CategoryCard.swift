import SwiftUI

struct CategoryCard: View {
    var description: String
    var amount: String
    var subtitle: String
    var backgroundColor: Color
    var imageName: String
    var isDarkMode: Bool // 🔥 Nuevo booleano
    
    var textColor: Color {
        isDarkMode ? .white : .black
    }
    
    var body: some View {
        ZStack {
            backgroundColor
            
            VStack(alignment: .leading, spacing: 8) {
                // Descripción
                Text(description)
                    .font(.headline)
                    .foregroundColor(textColor)
                    .lineLimit(2)
                    .minimumScaleFactor(0.8)
                
                Spacer()
                
                // Icono y monto
                HStack(alignment: .bottom) {
                    VStack(alignment: .leading, spacing: 4) {
                        Text(subtitle)
                            .font(.caption)
                            .foregroundColor(textColor)
                            .lineLimit(nil)
                            .fixedSize(horizontal: false, vertical: true)
                            .frame(maxWidth: 80)
                        
                        Text(amount)
                            .font(.title)
                            .foregroundColor(textColor)
                    }
                    
                    Spacer()
                    
                    Image(imageName)
                        .resizable()
                        .scaledToFit()
                        .frame(height: 70)
                }
            }
            .padding()
        }
        .frame(width: 160, height: 160)
        .cornerRadius(20)
    }
}

#Preview {
    CategoryCard(
        description: "Streaming",
        amount: "$30",
        subtitle: "Inferior a la media",
        backgroundColor: Color.yellow.opacity(0.7),
        imageName: "tele",
        isDarkMode: false // 🔥 Cambia aquí para ver blanco o negro
    )
}
