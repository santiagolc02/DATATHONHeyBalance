//
//  ContentView.swift
//  Heyapp
//
//  Created by Joel Vargas on 24/05/25.
//
import SwiftUI

struct ContentView: View {
    @State var move = false
    
    var body: some View {
        ZStack {
            // Fondo para ContentView (opcional si quieres un fondo aquí)
            Color.black.ignoresSafeArea()
            
            VStack {
                if move {
                    Home() // Se mostrará después de 2 segundos
                } else {
                    Image("heylogo")
                        .resizable()
                        .scaledToFit() // Mantiene proporciones
                        .frame(width: 200)
                }
            }
        }
        .onAppear {
            DispatchQueue.main.asyncAfter(deadline: .now() + 2) {
                move = true
            }
        }
    }
}

#Preview {
    ContentView()
}
