//
//  BalanceView.swift
//  Heyapp
//
//  Created by Joel Vargas on 25/05/25.
//
import SwiftUI

struct BalanceView: View {
    @State private var balanceData: BalanceData? = nil
    @State private var selectedIndex = 0 // 🔥 Para controlar el CustomNavbar
    
    var body: some View {
        ZStack {
            RadialGradient(
                gradient: Gradient(colors: [
                    Color(red: 0.27, green: 0.3, blue: 0.4),
                    Color.black.opacity(1)
                ]),
                center: .top,
                startRadius: 10,
                endRadius: 500
            )
            .ignoresSafeArea()
            
            VStack(spacing: 0) {
                ScrollView {
                    VStack(alignment: .leading, spacing: 24) {
                        
                        // 🔥 Encabezado
                        HStack {
                            Image("heylogo")
                                .resizable()
                                .scaledToFit()
                                .frame(width: 90)
                            Spacer()
                            Image(systemName: "line.horizontal.3.decrease.circle")
                                .foregroundColor(.white)
                                .font(.title)
                        }
                        .padding(.horizontal)
                        .padding(.top, 10)
                        
                        // 🔥 Gráfica con BalanceChartView
                        VStack(alignment: .leading, spacing: 12) {
                            Text("Tendencia")
                                .font(.title)
                                .bold()
                                .foregroundColor(.white)
                                .padding(.horizontal)
                                .padding()
                            
                            ZStack {
                                if let data = balanceData {
                                    BalanceChartView(data: data)
                                        .frame(height: 200)
                                } else {
                                    ProgressView()
                                        .progressViewStyle(CircularProgressViewStyle(tint: .green))
                                }
                            }
                            .frame(height: 200)
                            .padding(.horizontal)
                        }
                        .background(Color(.systemBackground).opacity(0.1))
                        .cornerRadius(20)
                        .padding(.horizontal)
                        
                        // 🔥 Categorías
                        VStack(alignment: .leading, spacing: 12) {
                            Text("Gastos por categoría")
                                .font(.title)
                                .bold()
                                .foregroundColor(.white)
                                .padding(.horizontal)
                                .padding(.top, 8)
                            
                            Text("Posibles gastos hormiga")
                                .font(.subheadline)
                                .foregroundColor(.gray)
                                .padding(.horizontal)
                            
                            LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: 16) {
                                CategoryCard(description: "Streaming", amount: "$30", subtitle: "Arriba de la media", backgroundColor: Color.yellow.opacity(0.7), imageName: "tele", isDarkMode: false)
                                CategoryCard(description: "Comida", amount: "$30", subtitle: "Arriba de la media", backgroundColor: Color.black, imageName: "pizza", isDarkMode: true)
                                CategoryCard(description: "Transporte", amount: "$30", subtitle: "Arriba de la media", backgroundColor: Color.green.opacity(0.7), imageName: "car", isDarkMode: false)
                                CategoryCard(description: "Compras", amount: "$30", subtitle: "Arriba de la media", backgroundColor: Color.purple.opacity(0.7), imageName: "bolsa", isDarkMode: false)
                            }
                            .padding()
                        }
                        .background(Color(.systemBackground).opacity(0.1))
                        .cornerRadius(20)
                        .padding(.horizontal)
                        
                        Spacer(minLength: 80) // 🔥 Espacio para que no tape la navbar
                    }
                }
                
                // 🔥 CustomNavbar al fondo
                CustomNavbar() // Tu navbar con imágenes
                    .padding(.bottom, 20)
                    .padding(.top, -20)            }
        }
        .onAppear {
            fetchBalanceData()
        }
    }
    
    private func fetchBalanceData() {
        guard let url = URL(string: "https://heyapiii-production.up.railway.app") else { return }
        Task {
            do {
                let (data, _) = try await URLSession.shared.data(from: url)
                // 🔥 Decodificar JSON en el formato proporcionado
                let decoded = try JSONDecoder().decode(BalanceData.self, from: data)
                DispatchQueue.main.async {
                    self.balanceData = decoded
                }
            } catch {
                print("Error al cargar o decodificar datos: \(error.localizedDescription)")
            }
        }
    }

}

#Preview {
    BalanceView()
}
