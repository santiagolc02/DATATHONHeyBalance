//
//  actionSheet.swift
//  Heyapp
//
//  Created by Joel Vargas on 24/05/25.
//

import SwiftUI

struct RoundedCornerShape: Shape {
    var radius: CGFloat = 20
    var corners: UIRectCorner = .allCorners

    func path(in rect: CGRect) -> Path {
        let path = UIBezierPath(
            roundedRect: rect,
            byRoundingCorners: corners,
            cornerRadii: CGSize(width: radius, height: radius)
        )
        return Path(path.cgPath)
    }
}

// MARK: - Modelo de Transacción
struct Transaction: Identifiable {
    let id = UUID()
    let date: Date
    let type: TransactionType
    let category: String
    let description: String
    let amount: Double
}

enum TransactionType {
    case income
    case expense
}

// MARK: - Vista
struct CustomActionSheet: View {
    var transactions: [Transaction]
    
    // Agrupar transacciones por fecha
    private var groupedTransactions: [String: [Transaction]] {
        Dictionary(grouping: transactions) { transaction in
            let formatter = DateFormatter()
            formatter.dateStyle = .medium
            return formatter.string(from: transaction.date)
        }
    }
    
    var body: some View {
        ZStack {
            VStack(spacing: 0) {
                Spacer()
                
                VStack(spacing: 16) {
                    VStack(alignment: .leading, spacing: 14) {
                        Text("Transactions")
                            .font(.title2)
                            .fontWeight(.semibold)
                            .foregroundColor(.white)
                        
                        ForEach(groupedTransactions.keys.sorted(by: >), id: \.self) { dateKey in
                            Text(dateKey)
                                .font(.subheadline)
                                .foregroundColor(.gray)
                            
                            ForEach(groupedTransactions[dateKey] ?? []) { transaction in
                                TransactionRow(transaction: transaction)
                            }
                        }
                    }
                    .padding(.horizontal)
                    .padding(.bottom, 8)
                    .padding(.top, 22)
                }
                .background(
                    Color(.systemBackground)
                        .opacity(0.1)
                )
                .clipShape(RoundedCornerShape(radius: 20, corners: [.topLeft, .topRight])) // 🔥 Solo arriba
                .frame(maxWidth: .infinity)
                .transition(.move(edge: .bottom))
            }
        }
    }
}

// MARK: - Componente de fila de transacción
struct TransactionRow: View {
    var transaction: Transaction
    
    var icon: String {
        transaction.type == .income ? "arrow.down" : "arrow.up"
    }
    
    var iconColor: Color {
        transaction.type == .income ? .gray : .yellow
    }
    
    var amountText: String {
        let amount = String(format: "%.2f", abs(transaction.amount))
        return transaction.type == .income ? "+ $\(amount)" : "- $\(amount)"
    }
    
    var body: some View {
        HStack {
            ZStack {
                Circle()
                    .fill(iconColor.opacity(0.2))
                    .frame(width: 40, height: 40)
                Image(systemName: icon)
                    .foregroundColor(iconColor)
            }
            VStack(alignment: .leading) {
                Text(transaction.category)
                    .foregroundColor(.white)
                    .font(.headline)
                Text(transaction.description)
                    .foregroundColor(.gray)
                    .font(.subheadline)
            }
            Spacer()
            Text(amountText)
                .foregroundColor(.white)
                .font(.headline)
        }
    }
}

#Preview {
    CustomActionSheet(
        transactions: [
            Transaction(date: Date(), type: .income, category: "Transfer", description: "Pago recibido de Juan", amount: 2450.0),
            Transaction(date: Date(), type: .expense, category: "Supermercado", description: "Compra en Walmart", amount: 875.5),
            Transaction(date: Calendar.current.date(byAdding: .day, value: -1, to: Date())!, type: .income, category: "Salario", description: "Pago mensual", amount: 4500.0)
        ]
    )
}
