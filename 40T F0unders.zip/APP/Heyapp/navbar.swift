//
//  navbar.swift
//  Heyapp
//
//  Created by Joel Vargas on 24/05/25.
//

import SwiftUI

struct CustomNavbar: View {
    @State private var selectedIndex = 0
    
    var body: some View {
        HStack {
            Spacer()
            NavbarButton(imageName: "Home", index: 0, selectedIndex: $selectedIndex)
            Spacer()
            NavbarButton(imageName: "Frame-1", index: 1, selectedIndex: $selectedIndex)
            Spacer()
            NavbarButton(imageName: "Frame-3", index: 2, selectedIndex: $selectedIndex)
            Spacer()
            NavbarButton(imageName: "Frame-2", index: 3, selectedIndex: $selectedIndex)
            Spacer()
            NavbarButton(imageName: "Frame", index: 4, selectedIndex: $selectedIndex)
            Spacer()
        }
        .padding(.vertical, 12)
        .background(Color(.sRGB, red: 0.137, green: 0.133, blue: 0.137, opacity: 1))
        
        .shadow(radius: 10)
    }
}

struct NavbarButton: View {
    var imageName: String
    var index: Int
    @Binding var selectedIndex: Int
    
    var body: some View {
        Button(action: {
            selectedIndex = index
        }) {
            Image(imageName)
                .resizable()
                .scaledToFit()
                .frame(width: 30, height: 30)
                .padding(8)
                .background(selectedIndex == index ? Color.yellow.opacity(0.2) : Color.clear)
                .clipShape(Circle())
        }
    }
}

#Preview {
    CustomNavbar()
}
