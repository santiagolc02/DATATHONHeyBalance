//
//  BalanceChartView.swift
//  Heyapp
//
//  Created by Joel Vargas on 25/05/25.
//

//
//  BalanceChartView.swift
//  Heyapp
//
//  Created by Joel Vargas on 25/05/25.
//

//
//  BalanceChartView.swift
//  Heyapp
//
//  Created by Joel Vargas on 25/05/25.
//

import SwiftUI

struct BalanceChartView: View {
    let data: BalanceData
    
    var body: some View {
        GeometryReader { geo in
            let width = geo.size.width
            let height = geo.size.height
            let minY = data.balances.min() ?? 0
            let maxY = data.balances.max() ?? 1
            
            let puntos: [CGPoint] = data.balances.enumerated().map { index, balance in
                let x = width * CGFloat(index) / CGFloat(data.balances.count - 1)
                let y = height * (1 - CGFloat((balance - minY) / (maxY - minY)))
                return CGPoint(x: x, y: y)
            }
            
            ZStack {
                let corteIndex = data.fechas.firstIndex(of: "2023-01-21") ?? data.balances.count - 1
                
                // ✨ Línea azul (normal) hasta el 2023-01-20
                Path { path in
                    guard corteIndex > 0 else { return }
                    path.move(to: puntos[0])
                    for index in 1..<corteIndex {
                        path.addLine(to: puntos[index])
                    }
                }
                .stroke(Color.white.opacity(0.8), style: StrokeStyle(lineWidth: 3, lineCap: .round, lineJoin: .round))
                
                // ✨ Línea punteada azul brillante (tendencia) a partir del 2023-01-21
                if corteIndex < data.balances.count - 1 {
                    Path { path in
                        path.move(to: puntos[corteIndex])
                        for index in corteIndex+1..<puntos.count {
                            path.addLine(to: puntos[index])
                        }
                    }
                    .stroke(LinearGradient(
                        gradient: Gradient(colors: [Color.cyan.opacity(0.9), Color.blue.opacity(0.9)]),
                        startPoint: .leading,
                        endPoint: .trailing
                    ), style: StrokeStyle(lineWidth: 5, lineCap: .round, lineJoin: .round, dash: [6]))
                    .shadow(color: Color.cyan.opacity(0.8), radius: 10, x: 0, y: 0) // 🔥 Brillo
                    
                    let tendenciaPoint = puntos[corteIndex]
                    Text("Tendencia")
                        .font(.caption)
                        .foregroundColor(.cyan.opacity(0.9))
                        .position(x: tendenciaPoint.x + 40, y: tendenciaPoint.y - 20)
                    
                    // 📅 Línea vertical "Hoy" en blanco
                    let hoyX = tendenciaPoint.x
                    Path { path in
                        path.move(to: CGPoint(x: hoyX, y: 0))
                        path.addLine(to: CGPoint(x: hoyX, y: height))
                    }
                    .stroke(Color.white.opacity(0.8), style: StrokeStyle(lineWidth: 2, dash: [4]))
                    
                    Text("Hoy")
                        .font(.caption)
                        .foregroundColor(.white.opacity(0.8))
                        .position(x: hoyX + 20, y: 20)
                }
                
                // ➖ Línea horizontal "Gastos recurrentes" en blanco
                let gasto = 3300.0
                let gastoY = height * (1 - CGFloat((gasto - minY) / (maxY - minY)))
                Path { path in
                    path.move(to: CGPoint(x: 0, y: gastoY))
                    path.addLine(to: CGPoint(x: width, y: gastoY))
                }
                .stroke(style: StrokeStyle(lineWidth: 1, dash: [5]))
                .foregroundColor(.white.opacity(0.8))
                
                Text("Gastos recurrentes")
                    .font(.caption)
                    .foregroundColor(.white.opacity(0.8))
                    .position(x: width * 0.3, y: gastoY - 10)
                
                // ➕ Línea vertical "Fin de mes" en blanco
                let finDeMesIndex = data.balances.count - 1
                let finDeMesX = width * CGFloat(finDeMesIndex) / CGFloat(data.balances.count - 1)
                Path { path in
                    path.move(to: CGPoint(x: finDeMesX, y: 0))
                    path.addLine(to: CGPoint(x: finDeMesX, y: height))
                }
                .stroke(style: StrokeStyle(lineWidth: 1, dash: [3]))
                .foregroundColor(.white.opacity(0.8))
                
                Text("Fin de mes")
                    .font(.caption)
                    .foregroundColor(.white.opacity(0.8))
                    .position(x: finDeMesX - 30, y: 20)
            }
        }
    }
}
