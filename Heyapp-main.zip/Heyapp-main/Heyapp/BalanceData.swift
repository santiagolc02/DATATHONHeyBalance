//
//  BalanceData.swift
//  Heyapp
//
//  Created by Joel Vargas on 25/05/25.
//

import Foundation


struct BalanceData: Decodable, Equatable {
    let fechas: [String]
    let balances: [Double]
}
