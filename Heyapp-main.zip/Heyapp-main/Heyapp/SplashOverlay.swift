//
//  SplashOverlay.swift
//  Heyapp
//
//  Created by Joel Vargas on 25/05/25.
//
import SwiftUI

struct SplashOverlay: View {
    @State private var showBalanceView = false // 🔥 Booleano para cambiar la vista

    var body: some View {
        ZStack {
            if showBalanceView {
                BalanceView() // 🔥 Cuando es true, muestra BalanceView
            } else {
                ZStack {
                    Color.black.opacity(0.7)
                        .ignoresSafeArea()
                    
                    Image("splash")
                        .resizable()
                        .scaledToFit()
                        .frame(width: 450, height: 450)
                        .padding(.top, -150)
                    
                    Button(action: {
                        withAnimation {
                            showBalanceView = true // 🔥 Cambiar booleano al presionar
                        }
                    }) {
                        Label("", systemImage: "arrow.right.circle.fill")
                            .font(.system(size: 43, weight: .bold))
                            .foregroundColor(.white)
                            .padding(.leading, 273)
                            .padding(.top, 245)
                    }
                }
            }
        }
    }
}

#Preview {
    SplashOverlay()
}
