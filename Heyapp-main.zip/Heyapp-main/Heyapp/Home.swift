//
//  Home.swift
//  Heyapp
//
//  Created by Joel Vargas on 24/05/25.
//
import SwiftUI

struct Home: View {
    @State var balance = false
    
    let sampleTransactions = [
        Transaction(date: Date(), type: .income, category: "Transferencia", description: "Pago recibido de Juan", amount: 2450.0),
        Transaction(date: Date(), type: .expense, category: "Supermercado", description: "Compra en Walmart", amount: 875.5),
        Transaction(date: Calendar.current.date(byAdding: .day, value: -1, to: Date())!, type: .income, category: "Salario", description: "Pago mensual", amount: 4500.0),
        Transaction(date: Calendar.current.date(byAdding: .day, value: -1, to: Date())!, type: .expense, category: "Restaurante", description: "Cena en La Parrilla", amount: 670.0),
        Transaction(date: Calendar.current.date(byAdding: .day, value: -2, to: Date())!, type: .income, category: "Reembolso", description: "Devolución de Amazon", amount: 320.0),

    ]
    
    var body: some View {
        ZStack {
            RadialGradient(
                gradient: Gradient(colors: [
                    Color(red: 0.27, green: 0.3, blue: 0.4),
                    Color.black.opacity(1)
                ]),
                center: .top,
                startRadius: 10,
                endRadius: 500
            )
            .ignoresSafeArea()
            
            VStack(spacing: 20) {
                
                
                Image("heylogo")
                    .resizable()
                    .scaledToFit()
                    .frame(height: 50)
                    .padding(.bottom, 10)
                    .padding(.top, 30)
                
                Image("card")
                    .resizable()
                    .scaledToFit()
                    .frame(height: 200)
                                
                CustomActionSheet(transactions: sampleTransactions)
                    .transition(.move(edge: .bottom))
                    .zIndex(1) // Asegura que está sobre todo
                
                CustomNavbar() // Tu navbar con imágenes
                    .padding(.bottom, 20)
                    .padding(.top, -20)
                
                
            }
            .overlay(
                    Group {
                        if balance {
                                    SplashOverlay()
                                        .transition(.opacity)
                                }
                    }
                    )
            
        
                
            
            
        }
        
        .onAppear {
            DispatchQueue.main.asyncAfter(deadline: .now() + 2) {
                withAnimation(.easeInOut(duration: 1)) {
                           balance = true
                       }
            }
        }
    }
}

#Preview {
    Home()
}
