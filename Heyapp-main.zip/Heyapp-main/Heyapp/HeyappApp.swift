//
//  HeyappApp.swift
//  Heyapp
//
//  Created by Joel Vargas on 24/05/25.
//

import SwiftUI

@main
struct HeyappApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
