//
//  HeyappTests.swift
//  HeyappTests
//
//  Created by Joel Vargas on 24/05/25.
//

import Testing
@testable import Heyapp

struct HeyappTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
