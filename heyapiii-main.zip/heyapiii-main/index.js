const fs = require('fs');
const path = require('path');
const csv = require('csv-parser');
const express = require('express');

const app = express();
const PORT = process.env.PORT || 3000;

// Ruta al archivo 'forecasted_balances.csv'
const forecastedCsvPath = path.join(__dirname, 'forecasted_balances.csv');

// Función para leer y procesar 'forecasted_balances.csv'
function readForecastedCSV(res) {
  const fechas = [];
  const balances = [];

  if (!fs.existsSync(forecastedCsvPath)) {
    return res.status(500).send(`❌ No se encontró el archivo CSV en: ${forecastedCsvPath}`);
  }

  fs.createReadStream(forecastedCsvPath)
    .pipe(csv())
    .on('data', (data) => {
      fechas.push(data.fecha);
      balances.push(parseFloat(data.balance));
    })
    .on('end', () => {
      // Agrega aquí las claves adicionales que desees incluir en el JSON
      res.json({
        fechas,
        balances,
        will_fake: true 
      });
    })
    .on('error', (err) => {
      res.status(500).send('❌ Error leyendo CSV: ' + err.message);
    });
}

// Ruta raíz que devuelve los datos de 'forecasted_balances.csv' con claves adicionales
app.get('/', (req, res) => {
  readForecastedCSV(res);
});

app.listen(PORT, '0.0.0.0', () => {
  console.log(`🚀 Servidor corriendo en http://localhost:${PORT}`);
});
